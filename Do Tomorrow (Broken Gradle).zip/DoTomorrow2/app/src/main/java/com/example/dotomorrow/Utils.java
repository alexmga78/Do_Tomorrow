package com.example.dotomorrow;

import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.WindowMetrics;

public class Utils {

    public Utils() {
    }


    public void SortTasks_byName() {

    }
    public void SortTasks_byName_reverse() {

    }
    public void SortTasks_byDate() {

    }
    public void SortTasks_byDate_reverse() {

    }
    public void SortTasks_byLevel() {

    }
    public void SortTasks_byCategories() {

    }
}
